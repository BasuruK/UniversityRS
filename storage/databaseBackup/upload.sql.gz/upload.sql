-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: universityrs
-- ------------------------------------------------------
-- Server version	5.7.16-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrator_options`
--

DROP TABLE IF EXISTS `administrator_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrator_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semesterRequestForm` tinyint(1) NOT NULL DEFAULT '0',
  `SMSNotificationsForUsers` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrator_options`
--

LOCK TABLES `administrator_options` WRITE;
/*!40000 ALTER TABLE `administrator_options` DISABLE KEYS */;
INSERT INTO `administrator_options` VALUES (1,1,0,'2016-11-19 02:42:26','2016-11-19 02:42:26');
/*!40000 ALTER TABLE `administrator_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowed_users`
--

DROP TABLE IF EXISTS `allowed_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowed_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `allowed_users_staff_id_unique` (`staff_id`),
  KEY `allowed_users_position_foreign` (`position`),
  CONSTRAINT `allowed_users_position_foreign` FOREIGN KEY (`position`) REFERENCES `priority` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowed_users`
--

LOCK TABLES `allowed_users` WRITE;
/*!40000 ALTER TABLE `allowed_users` DISABLE KEYS */;
INSERT INTO `allowed_users` VALUES (1,'IT14000000',1,'2016-11-11 20:21:06','2016-11-11 20:21:06'),(2,'IT14024764',1,'2016-11-19 02:30:39','2016-11-19 02:30:39'),(3,'IT14020254',2,'2016-11-19 02:30:56','2016-11-19 02:30:56'),(4,'IT14030222',1,'2016-11-19 03:09:27','2016-11-19 03:09:27');
/*!40000 ALTER TABLE `allowed_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `noOfStudents` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batchNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_year_index` (`year`),
  KEY `batch_batchno_index` (`batchNo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch`
--

LOCK TABLES `batch` WRITE;
/*!40000 ALTER TABLE `batch` DISABLE KEYS */;
INSERT INTO `batch` VALUES (1,'1','120','1','weekday','2016-11-11 20:21:06','2016-11-11 20:21:06'),(2,'1','135','2','weekday','2016-11-11 20:21:06','2016-11-11 20:21:06'),(3,'1','90','3','weekend','2016-11-11 20:21:06','2016-11-11 20:21:06'),(4,'2','70','1','weekday','2016-11-11 20:21:06','2016-11-11 20:21:06'),(5,'2','65','2','weekend','2016-11-11 20:21:06','2016-11-11 20:21:06'),(6,'3','20','1','weekday','2016-11-11 20:21:06','2016-11-11 20:21:06'),(7,'3','20','1 Curtin','weekday','2016-11-13 22:12:23','2016-11-13 22:12:23');
/*!40000 ALTER TABLE `batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deadlines`
--

DROP TABLE IF EXISTS `deadlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deadlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deadline` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deadlines`
--

LOCK TABLES `deadlines` WRITE;
/*!40000 ALTER TABLE `deadlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `deadlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8_unicode_ci NOT NULL,
  `queue` text COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_reserved_at_index` (`queue`,`reserved`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_foreign` (`user_id`),
  CONSTRAINT `messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_05_09_000001_create_priority_table',1),('2014_05_10_100617_create_allowed_to_register_users_table',1),('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_05_25_142048_create_subject_table',1),('2016_05_25_145650_create_batch_table',1),('2016_05_25_162520_create_resource_table',1),('2016_05_26_102334_create_requests_table',1),('2016_05_30_043638_add_foreign_key_to_allowed_users_table',1),('2016_06_01_060318_create_timetable_table',1),('2016_07_21_175057_create_deadlines_table',1),('2016_07_24_160015_create_timeFormatTable_table',1),('2016_07_28_144342_create_administrator_options_table',1),('2016_07_29_085540_create_semester_requests_table',1),('2016_07_30_122229_create_notifications_table',1),('2016_08_07_124748_create_messages_table',1),('2016_09_01_141626_create_jobs_table',1),('2016_11_10_172118_create_failed_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notification` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `forAdmin` tinyint(1) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'Semester Form now Available',0,'/userRequest/requestFormSemester/','semesterRequestFormNotification','2016-11-19 02:42:26','2016-11-19 02:42:26');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority`
--

DROP TABLE IF EXISTS `priority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priority` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `priorityName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `priorityValue` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority`
--

LOCK TABLES `priority` WRITE;
/*!40000 ALTER TABLE `priority` DISABLE KEYS */;
INSERT INTO `priority` VALUES (1,'Administrator',100,NULL,NULL),(2,'Dean',10,NULL,NULL),(3,'Professor',9,NULL,NULL),(4,'Doctor',8,NULL,NULL),(5,'Senior Lecturer',7,NULL,NULL),(6,'Assistant Lecturer',6,NULL,NULL);
/*!40000 ALTER TABLE `priority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lecturerID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `batchNo` int(10) unsigned DEFAULT NULL,
  `subjectCode` int(10) unsigned DEFAULT NULL,
  `requestDate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resourceID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeslotType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialEvent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ResourceType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `requests_batchno_index` (`batchNo`),
  KEY `requests_subjectcode_index` (`subjectCode`),
  KEY `requests_resourceid_foreign` (`resourceID`),
  CONSTRAINT `requests_batchno_foreign` FOREIGN KEY (`batchNo`) REFERENCES `batch` (`id`) ON DELETE CASCADE,
  CONSTRAINT `requests_resourceid_foreign` FOREIGN KEY (`resourceID`) REFERENCES `resource` (`hallNo`) ON DELETE CASCADE,
  CONSTRAINT `requests_subjectcode_foreign` FOREIGN KEY (`subjectCode`) REFERENCES `subject` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests`
--

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
INSERT INTO `requests` VALUES (1,'IT14020254',NULL,NULL,NULL,'2016-11-19-Sat','8:30 - 10:30','B506','Accepted','3','50','Workshop','LectureHall','2016-11-19 03:20:21','2016-11-19 03:21:03'),(3,'IT14020254','1',2,8,'2016-11-25-Fri','14.30 - 16.30',NULL,'','2',NULL,NULL,'LectureHall','2016-11-19 07:58:54','2016-11-19 07:59:09');
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hallNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_hallno_index` (`hallNo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
INSERT INTO `resource` VALUES (1,'B501','LectureHall','100','2016-11-11 20:21:06','2016-11-11 20:21:06'),(2,'B502','LectureHall','130','2016-11-11 20:21:06','2016-11-11 20:21:06'),(3,'B506','LectureHall','70','2016-11-11 20:21:06','2016-11-11 20:21:06'),(4,'B403','Lab','46','2016-11-11 20:21:06','2016-11-11 20:21:06'),(5,'D201','LectureHall','46','2016-11-11 20:21:06','2016-11-11 20:21:06'),(6,'B402','Lab','35','2016-11-19 02:32:38','2016-11-19 02:32:59'),(9,'B401','Lab','59','2016-11-19 03:47:36','2016-11-19 03:52:34'),(10,'B405','Lab','56','2016-11-19 03:48:50','2016-11-19 03:48:50'),(11,'B406','Lab','63','2016-11-19 03:49:40','2016-11-19 03:49:40'),(12,'B404','Lab','20','2016-11-19 03:50:01','2016-11-19 03:50:01'),(13,'B4010','Lab','10','2016-11-19 03:51:33','2016-11-19 03:51:33'),(14,'B4011','Lab','60','2016-11-19 03:51:59','2016-11-19 03:51:59'),(15,'B507','LectureHall','96','2016-11-19 03:53:14','2016-11-19 03:53:14'),(16,'B505','LectureHall','48','2016-11-19 03:53:28','2016-11-19 03:53:28'),(17,'B705','LectureHall','96','2016-11-19 03:54:13','2016-11-19 03:54:13'),(18,'IMLab','Lab','18','2016-11-19 03:55:17','2016-11-19 03:55:17'),(21,'A505','LectureHall','100','2016-11-20 05:11:05','2016-11-20 05:11:05');
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semester_requests`
--

DROP TABLE IF EXISTS `semester_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semester_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lecturerID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batchNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subjectCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `requestDate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resourceID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeslotType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ResourceType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semester_requests`
--

LOCK TABLES `semester_requests` WRITE;
/*!40000 ALTER TABLE `semester_requests` DISABLE KEYS */;
INSERT INTO `semester_requests` VALUES (1,'IT14020254','1','1','5','monday','8.30 - 10.30','B506','Accepted','1','2','LectureHall','2016-11-19 03:34:34','2016-11-19 03:55:58'),(2,'IT14020254','1','1','7','tuesday','8.30 - 10.30','B507','Accepted','1','2','LectureHall','2016-11-19 03:38:37','2016-11-19 03:56:20'),(3,'IT14020254','1','1','7','tuesday','16.30 - 18.30','B405','Accepted','1','2','Lab','2016-11-19 03:39:14','2016-11-19 03:58:25'),(4,'IT14020254','1','1','7','tuesday','15.30 - 16.30','B705','Accepted','1','1','LectureHall','2016-11-19 03:39:56','2016-11-19 03:58:48'),(5,'IT14020254','1','1','5','monday','14.30 - 16.30','B404','Accepted','1','2','Lab','2016-11-19 03:40:19','2016-11-19 03:59:10'),(6,'IT14020254','1','1','5','monday','10.30 - 11.30','D201','Accepted','1','1','LectureHall','2016-11-19 03:41:03','2016-11-19 03:59:27'),(7,'IT14020254','1','1','9','wednesday','8.30 - 10.30','B507','Accepted','1','2','LectureHall','2016-11-19 03:41:57','2016-11-19 03:59:42'),(8,'IT14020254','1','1','14','thursday','8.30 - 10.30','B505','Accepted','1','2','LectureHall','2016-11-19 03:42:31','2016-11-19 03:59:58'),(9,'IT14020254','1','1','14','thursday','16.30 - 18.30','B402','Accepted','1','2','Lab','2016-11-19 03:42:54','2016-11-19 03:46:53'),(10,'IT14020254','1','1','14','thursday','15.30 - 16.30','B506','Accepted','1','1','LectureHall','2016-11-19 03:43:22','2016-11-19 04:00:27'),(11,'IT14020254','1','1','8','friday','8.30 - 10.30','B502','Accepted','1','2','LectureHall','2016-11-19 03:44:20','2016-11-19 04:00:43'),(12,'IT14020254','1','1','8','friday','16.30 - 18.30','B705','Accepted','1','2','LectureHall','2016-11-19 03:44:48','2016-11-19 04:01:27');
/*!40000 ALTER TABLE `semester_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_subcode_index` (`subCode`),
  KEY `subject_semester_index` (`semester`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (1,'SC400','1','Software Components','3','2016-11-11 20:21:06','2016-11-11 20:21:06'),(2,'PDM300','1','Project Design and Management','3','2016-11-11 20:21:06','2016-11-11 20:21:06'),(3,'IT300','2','Operating Systems','3','2016-11-11 20:21:06','2016-11-11 20:21:06'),(4,'IT300','1','Computer Graphics and Multimedia','2','2016-11-11 20:21:06','2016-11-19 02:41:22'),(5,'MA120','2','Mathematics for Information Technology','1','2016-11-11 20:21:06','2016-11-19 02:55:02'),(7,'IT201','1','Computer Fundamentals ','1','2016-11-19 02:55:57','2016-11-19 02:55:57'),(8,'IT202','1','Introduction To Programming Environment','1','2016-11-19 02:56:50','2016-11-19 02:56:50'),(9,'ELSI','1','English Language Skills','1','2016-11-19 03:03:33','2016-11-19 03:03:33'),(10,'IT204','2','Information Technology Applications','1','2016-11-19 03:07:55','2016-11-19 03:07:55'),(11,'IT206','2','Database Management Management I','1','2016-11-19 03:12:32','2016-11-19 03:12:48'),(12,'ELSII','2','English Language Skills II','1','2016-11-19 03:14:53','2016-11-19 03:14:53'),(13,'IT208','2','Software Technology I','1','2016-11-19 03:18:25','2016-11-19 03:18:25'),(14,'DC202','2','Data Communication And Computer Networks','1','2016-11-19 03:22:37','2016-11-19 03:22:37');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeFormatTable`
--

DROP TABLE IF EXISTS `timeFormatTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeFormatTable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time24Format` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeFormatTable`
--

LOCK TABLES `timeFormatTable` WRITE;
/*!40000 ALTER TABLE `timeFormatTable` DISABLE KEYS */;
INSERT INTO `timeFormatTable` VALUES (1,'8.30 - 9.30','8.30 - 9.30',NULL,NULL),(2,'9.30 - 10.30','9.30 - 10.30',NULL,NULL),(3,'10.30 - 11.30','10.30 - 11.30',NULL,NULL),(4,'11.30 - 12.30','11.30 - 12.30',NULL,NULL),(5,'12.30 - 1.30','12.30 - 13.30',NULL,NULL),(6,'1.30 - 2.30','13.30 - 14.30',NULL,NULL),(7,'2.30 - 3.30','14.30 - 15.30',NULL,NULL),(8,'3.30 - 4.30','15.30 - 16.30',NULL,NULL),(9,'4.30 - 5.30','16.30 - 17.30',NULL,NULL),(10,'5.30 - 6.30','17.30 - 18.30',NULL,NULL),(11,'6.30 - 7.30','18.30 - 19.30',NULL,NULL),(12,'7.30 - 8.30','19.30 - 20.30',NULL,NULL);
/*!40000 ALTER TABLE `timeFormatTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batchNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subjectCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `day` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resourceName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lecturerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `timetable_id_index` (`id`),
  KEY `timetable_year_index` (`year`),
  KEY `timetable_batchno_index` (`batchNo`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable`
--

LOCK TABLES `timetable` WRITE;
/*!40000 ALTER TABLE `timetable` DISABLE KEYS */;
INSERT INTO `timetable` VALUES (1,'1','1','Data Communication And Computer Networks','16.30 - 18.30','thursday','B402','Basuru Balasuriya','2016-11-19 03:46:53','2016-11-19 03:46:53'),(2,'1','1','Mathematics for Information Technology','8.30 - 10.30','monday','B506','Basuru Balasuriya','2016-11-19 03:55:58','2016-11-19 03:55:58'),(3,'1','1','Computer Fundamentals ','8.30 - 10.30','tuesday','B507','Basuru Balasuriya','2016-11-19 03:56:20','2016-11-19 03:56:20'),(4,'1','1','Computer Fundamentals ','10.30 - 12.30','tuesday','B4011','Basuru Balasuriya','2016-11-19 03:57:06','2016-11-19 03:57:06'),(5,'1','1','Computer Fundamentals ','16.30 - 18.30','tuesday','B405','Basuru Balasuriya','2016-11-19 03:58:25','2016-11-19 03:58:25'),(6,'1','1','Computer Fundamentals ','15.30 - 16.30','tuesday','B705','Basuru Balasuriya','2016-11-19 03:58:48','2016-11-19 03:58:48'),(7,'1','1','Mathematics for Information Technology','14.30 - 16.30','monday','B404','Basuru Balasuriya','2016-11-19 03:59:10','2016-11-19 03:59:10'),(8,'1','1','Mathematics for Information Technology','10.30 - 11.30','monday','D201','Basuru Balasuriya','2016-11-19 03:59:27','2016-11-19 03:59:27'),(9,'1','1','English Language Skills','8.30 - 10.30','wednesday','B507','Basuru Balasuriya','2016-11-19 03:59:42','2016-11-19 03:59:42'),(10,'1','1','Data Communication And Computer Networks','8.30 - 10.30','thursday','B505','Basuru Balasuriya','2016-11-19 03:59:58','2016-11-19 03:59:58'),(11,'1','1','Data Communication And Computer Networks','15.30 - 16.30','thursday','B506','Basuru Balasuriya','2016-11-19 04:00:27','2016-11-19 04:00:27'),(12,'1','1','Introduction To Programming Environment','8.30 - 10.30','friday','B502','Basuru Balasuriya','2016-11-19 04:00:43','2016-11-19 04:00:43'),(13,'1','1','Introduction To Programming Environment','14.30 - 16.30','friday','D201','Basuru Balasuriya','2016-11-19 04:01:14','2016-11-19 04:01:14'),(14,'1','1','Introduction To Programming Environment','16.30 - 18.30','friday','B705','Basuru Balasuriya','2016-11-19 04:01:27','2016-11-19 04:01:27');
/*!40000 ALTER TABLE `timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'avatar5.png',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_staff_id_unique` (`staff_id`),
  UNIQUE KEY `users_email_unique` (`email`),
  CONSTRAINT `users_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `allowed_users` (`staff_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'IT14000000','Administrator','notify.urscheduler@gmail.com','$2y$10$KKAuS.ROJypIYj2Oe.jqj.PDP0QafnRUDZSf.Rj5MGCpomKBP/3RO',1,'avatar5.png','xS0B7QyJNaFjpxgkqbX8E7k8PV1p8lQDfSknFsrvuzR1ctndNYLqBwwdfB6d','2016-11-11 20:21:06','2016-11-19 11:01:08'),(2,'IT14024764','Devin Sanduka','devin.qc@gmail.com','$2y$10$esYRvXro8.xN3RzNAGa4Ouy54rnTKcI2LmRC2gS69IEEoiqYPac.6',1,'avatar5.png','MMbhoPii0j31PcACog0kBlVOulAQMbTBMzKwr6xo91pGI8UNmVIrKCVrSk12','2016-11-19 02:31:08','2016-11-19 03:21:58'),(3,'IT14020254','Basuru Balasuriya','bestbasuru@live.com','$2y$10$g1Ho4mozmAE2vQjK0CLsNedsSNVtxsjHX82NuQhUOAxszgcyhM4ru',0,'avatar5.png','jha1qLAFSGveNYpqgGqsrSnfM9vazb6zK33J1eFHTGaFcLpqaEcIrnNYpmf5','2016-11-19 02:31:35','2016-11-19 07:59:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'universityrs'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-20 19:43:04
