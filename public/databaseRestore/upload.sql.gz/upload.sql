-- MySQL dump 10.13  Distrib 5.7.16, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: universityrs
-- ------------------------------------------------------
-- Server version	5.7.16-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administrator_options`
--

DROP TABLE IF EXISTS `administrator_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrator_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semesterRequestForm` tinyint(1) NOT NULL DEFAULT '0',
  `SMSNotificationsForUsers` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrator_options`
--

LOCK TABLES `administrator_options` WRITE;
/*!40000 ALTER TABLE `administrator_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `administrator_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `allowed_users`
--

DROP TABLE IF EXISTS `allowed_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allowed_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `allowed_users_staff_id_unique` (`staff_id`),
  KEY `allowed_users_position_foreign` (`position`),
  CONSTRAINT `allowed_users_position_foreign` FOREIGN KEY (`position`) REFERENCES `priority` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allowed_users`
--

LOCK TABLES `allowed_users` WRITE;
/*!40000 ALTER TABLE `allowed_users` DISABLE KEYS */;
INSERT INTO `allowed_users` VALUES (1,'IT14020254',1,'2016-11-02 10:53:19','2016-11-02 10:53:19'),(2,'IT14034978',2,'2016-11-02 10:53:19','2016-11-02 10:53:19'),(3,'IT14030222',1,'2016-11-02 10:53:19','2016-11-02 10:53:19'),(4,'IT14024764',1,'2016-11-02 10:53:19','2016-11-02 10:53:19'),(5,'IT14000000',1,'2016-11-02 10:53:19','2016-11-02 10:53:19');
/*!40000 ALTER TABLE `allowed_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `noOfStudents` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batchNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_year_index` (`year`),
  KEY `batch_batchno_index` (`batchNo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch`
--

LOCK TABLES `batch` WRITE;
/*!40000 ALTER TABLE `batch` DISABLE KEYS */;
INSERT INTO `batch` VALUES (1,'1','120','1','weekday','2016-11-02 10:53:20','2016-11-02 10:53:20'),(2,'1','135','2','weekday','2016-11-02 10:53:20','2016-11-02 10:53:20'),(3,'1','90','3','weekend','2016-11-02 10:53:20','2016-11-02 10:53:20'),(4,'2','70','1','weekday','2016-11-02 10:53:20','2016-11-02 10:53:20'),(5,'2','65','2','weekend','2016-11-02 10:53:20','2016-11-02 10:53:20'),(6,'3','20','1','weekday','2016-11-02 10:53:20','2016-11-02 10:53:20');
/*!40000 ALTER TABLE `batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deadlines`
--

DROP TABLE IF EXISTS `deadlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deadlines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `semester` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deadline` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deadlines`
--

LOCK TABLES `deadlines` WRITE;
/*!40000 ALTER TABLE `deadlines` DISABLE KEYS */;
/*!40000 ALTER TABLE `deadlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_reserved_at_index` (`queue`,`reserved`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_foreign` (`user_id`),
  CONSTRAINT `messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_05_09_000001_create_priority_table',1),('2014_05_10_100617_create_allowed_to_register_users_table',1),('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_05_25_142048_create_subject_table',1),('2016_05_25_145650_create_batch_table',1),('2016_05_25_162520_create_resource_table',1),('2016_05_26_102334_create_requests_table',1),('2016_05_30_043638_add_foreign_key_to_allowed_users_table',1),('2016_06_01_060318_create_timetable_table',1),('2016_07_21_175057_create_deadlines_table',1),('2016_07_24_160015_create_timeFormatTable_table',1),('2016_07_28_144342_create_administrator_options_table',1),('2016_07_29_085540_create_semester_requests_table',1),('2016_07_30_122229_create_notifications_table',1),('2016_08_07_124748_create_messages_table',1),('2016_09_01_141626_create_jobs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notification` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `forAdmin` tinyint(1) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `priority`
--

DROP TABLE IF EXISTS `priority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `priority` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `priorityName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `priorityValue` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `priority`
--

LOCK TABLES `priority` WRITE;
/*!40000 ALTER TABLE `priority` DISABLE KEYS */;
INSERT INTO `priority` VALUES (1,'Administrator',100,NULL,NULL),(2,'Dean',10,NULL,NULL),(3,'Professor',9,NULL,NULL),(4,'Doctor',8,NULL,NULL),(5,'Senior Lecturer',7,NULL,NULL),(6,'Assistant Lecturer',6,NULL,NULL);
/*!40000 ALTER TABLE `priority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lecturerID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `batchNo` int(10) unsigned DEFAULT NULL,
  `subjectCode` int(10) unsigned DEFAULT NULL,
  `requestDate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resourceID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeslotType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `specialEvent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ResourceType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `requests_batchno_index` (`batchNo`),
  KEY `requests_subjectcode_index` (`subjectCode`),
  KEY `requests_resourceid_foreign` (`resourceID`),
  CONSTRAINT `requests_batchno_foreign` FOREIGN KEY (`batchNo`) REFERENCES `batch` (`id`) ON DELETE CASCADE,
  CONSTRAINT `requests_resourceid_foreign` FOREIGN KEY (`resourceID`) REFERENCES `resource` (`hallNo`) ON DELETE CASCADE,
  CONSTRAINT `requests_subjectcode_foreign` FOREIGN KEY (`subjectCode`) REFERENCES `subject` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests`
--

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hallNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resource_hallno_index` (`hallNo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
INSERT INTO `resource` VALUES (1,'B501','LectureHall','100','2016-11-02 10:53:20','2016-11-02 10:53:20'),(2,'B502','LectureHall','130','2016-11-02 10:53:20','2016-11-02 10:53:20'),(3,'B506','LectureHall','70','2016-11-02 10:53:20','2016-11-02 10:53:20'),(4,'B403','Lab','46','2016-11-02 10:53:20','2016-11-02 10:53:20'),(5,'D201','LectureHall','46','2016-11-02 10:53:20','2016-11-02 10:53:20');
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semester_requests`
--

DROP TABLE IF EXISTS `semester_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semester_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lecturerID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batchNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subjectCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `requestDate` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resourceID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeslotType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ResourceType` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semester_requests`
--

LOCK TABLES `semester_requests` WRITE;
/*!40000 ALTER TABLE `semester_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `semester_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subject` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `semester` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_subcode_index` (`subCode`),
  KEY `subject_semester_index` (`semester`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subject`
--

LOCK TABLES `subject` WRITE;
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` VALUES (1,'SC400','1','Software Components','3','2016-11-02 10:53:20','2016-11-02 10:53:20'),(2,'PDM300','1','Project Design and Management','3','2016-11-02 10:53:20','2016-11-02 10:53:20'),(3,'IT300','2','Operating Systems','3','2016-11-02 10:53:20','2016-11-02 10:53:20'),(4,'IT240','1','Computer Graphics and Multimedia','2','2016-11-02 10:53:20','2016-11-02 10:53:20'),(5,'IT200','2','Mathematics for Information Technology','1','2016-11-02 10:53:20','2016-11-02 10:53:20');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeFormatTable`
--

DROP TABLE IF EXISTS `timeFormatTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeFormatTable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time24Format` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeFormatTable`
--

LOCK TABLES `timeFormatTable` WRITE;
/*!40000 ALTER TABLE `timeFormatTable` DISABLE KEYS */;
INSERT INTO `timeFormatTable` VALUES (1,'8.30 - 9.30','8.30 - 9.30',NULL,NULL),(2,'9.30 - 10.30','9.30 - 10.30',NULL,NULL),(3,'10.30 - 11.30','10.30 - 11.30',NULL,NULL),(4,'11.30 - 12.30','11.30 - 12.30',NULL,NULL),(5,'12.30 - 1.30','12.30 - 13.30',NULL,NULL),(6,'1.30 - 2.30','13.30 - 14.30',NULL,NULL),(7,'2.30 - 3.30','14.30 - 15.30',NULL,NULL),(8,'3.30 - 4.30','15.30 - 16.30',NULL,NULL),(9,'4.30 - 5.30','16.30 - 17.30',NULL,NULL),(10,'5.30 - 6.30','17.30 - 18.30',NULL,NULL),(11,'6.30 - 7.30','18.30 - 19.30',NULL,NULL),(12,'7.30 - 8.30','19.30 - 20.30',NULL,NULL);
/*!40000 ALTER TABLE `timeFormatTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timetable` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `year` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batchNo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subjectCode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timeSlot` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `day` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `resourceName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lecturerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `timetable_id_index` (`id`),
  KEY `timetable_year_index` (`year`),
  KEY `timetable_batchno_index` (`batchNo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timetable`
--

LOCK TABLES `timetable` WRITE;
/*!40000 ALTER TABLE `timetable` DISABLE KEYS */;
INSERT INTO `timetable` VALUES (1,'3 Curtin IT','1','NSD(P)','10.30 - 12.30','monday','B402','Sandamini Bandara',NULL,NULL),(2,'3 Curtin IT','1','HCI(L)','8.30 - 10.30','tuesday','A307','Sandamini Bandara',NULL,NULL),(3,'3 Curtin IT','1','HCI(P)','10.30 - 12.30','tuesday','B402','Sandamini Bandara',NULL,NULL),(4,'3 Curtin IT','1','HCI(T)','12.30 - 13.30','tuesday','A307','Sandamini Bandara',NULL,NULL),(5,'3 Curtin IT','1','NSD(L)','8.30 - 12.30','wednesday','D201','Sandamini Bandara',NULL,NULL),(6,'3 Curtin IT','1','NSD(T)','11.30 - 12.30','wednesday','D201','Sandamini Bandara',NULL,NULL),(7,'3 Curtin IT','1','ACC(L)','11.30 - 13.30','thursday','D201','Sandamini Bandara',NULL,NULL),(8,'3 Curtin IT','1','ACC(T)','13.30 - 15.30','thursday','D201','Sandamini Bandara',NULL,NULL),(9,'3 Curtin IT','1','ACC(P)','15.30 - 17.30','thursday','D201','Sandamini Bandara',NULL,NULL),(10,'3 Curtin IT','1','SEP(L)','13.30 - 15.30','friday','D201','Sandamini Bandara',NULL,NULL),(11,'3 Curtin IT','1','SEP(P)','15.30 - 17.30','friday','D201','Sandamini Bandara',NULL,NULL);
/*!40000 ALTER TABLE `timetable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'avatar5.png',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_staff_id_unique` (`staff_id`),
  UNIQUE KEY `users_email_unique` (`email`),
  CONSTRAINT `users_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `allowed_users` (`staff_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'IT14020254','Basuru Kusal','bestbasuru@live.com','$2y$10$jfOvGOQAgVNnyg5tOcvWM.rs9x2yRR1/nRAQAlNyHY5Nh9NqgOubO',1,'avatar5.png',NULL,'2016-11-02 10:53:19','2016-11-02 10:53:19'),(2,'IT14034978','Sandamini Bandara','sheydenb31@gmail.com','$2y$10$4/31PL9iTF.JscyHV8RxTucqp8LE0aW.0RxFZBRT5.xlOP7cMjlfC',0,'avatar5.png',NULL,'2016-11-02 10:53:19','2016-11-02 10:53:19'),(3,'IT14000000','Default User','notify.urscheduler@gmail.com','$2y$10$UB9ZRRtBezk9TFSGz0OsgOm.NuDlJwzkMjZwLfkOHuH23EESxfXfG',1,'avatar5.png',NULL,'2016-11-02 10:53:20','2016-11-02 10:53:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'universityrs'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-11-02 22:07:19
